var n, w, wh;
var icon = [];
var iconLeft = [];
var newWidth = [];
var newMargin = [];
var container, bg;
var intoInterval;
var intervalCount;
var movein = 0;
var pause = 0;
var cMargin;

var iconNumber = 10;
var iconMinWidth = 64;
var iconMaxWidth = 128;

var expandWidth = iconNumber * 64 + 230;


function init(){
	container = document.getElementById("container");
	var icons = container.childNodes;
	bg = document.getElementById("bg");
	n = 0;
	w = document.body.offsetWidth;
	wh = w * .5;
	for(var i = 0; i < icons.length; ++i)
		if(icons[i].tagName == "IMG"){
			iconLeft[n] = icons[i].getBoundingClientRect().left;
			icon[n++] = icons[i];
		}
	container.addEventListener("mouseenter", mouseEnter, false);
	container.addEventListener("mousemove", mouseMove, false); 
	container.addEventListener("mouseleave", mouseLeave, false);
}

function setSize(index, dist){
	if(Math.abs(dist) > 200){
		icon[index].style.width = "64px";
		return;
	}
	var s = Math.cos(dist / 200 * 3.1415926) * 32 + 96;
	icon[index].style.width = s + "px";
}

function getSize(dist){
	if(Math.abs(dist) > 200)
		return 64;
	return Math.cos(dist / 200 * 3.1415926) * 32 + 96;
}

function iconTrans(){
	if(intervalCount >= 5){
		movein = 1;
		pause = 0;
		clearInterval(intoInterval);
		return;
	}
	console.log(intervalCount);
	var t = 5 - intervalCount;
	for(var i = 0; i < n; ++i){
		icon[i].style.width = (newWidth[i] + icon[i].getBoundingClientRect().width * (t - 1)) / t + "px";
//		icon[i].style["margin-left"] = (newMargin[i] + (icon[i].style["margin-left"]) * (t - 1)) / t + "px";
	}
	container.style["margin-left"] = (cMargin + parseFloat(container.style["margin-left"]) * (t - 1)) / t + "px";
	++intervalCount;
}

function calcInitSize(x, ani){
	var tmp, minDis = -1000, leftIndex = -1, rightIndex = -1;
	var pos = -1;
	for(var i = 0; i < n; ++i){
		tmp = x - iconLeft[i] - 32;
		if(tmp <= 200){
			if(tmp < -200 && rightIndex == -1){
				rightIndex = i;
			}
			else if(leftIndex == -1){
				leftIndex = i;
			}
		}
	}
	if(leftIndex == 0){
		leftIndex = 0;
		pos = 0;
	}
	if(rightIndex == -1){
		rightIndex = n;
		pos = 1;
	}

	if(!movein){	
		var cWidth = 0;
		
		for(var i = 0; i < leftIndex; ++i){
			newWidth[i] = 64;
			cWidth += 64;
		}
		for(var i = leftIndex; i < rightIndex; ++i){
			newWidth[i] = getSize(x - iconLeft[i] - 32);
			cWidth += newWidth[i];
		}
		for(var i =  rightIndex; i < n; ++i){
			newWidth[i] = 64;
			cWidth += 64;
		}
		cWidth += (n - 1) * 5;
		
		if(pos == 0){  
			cMargin = expandWidth - cWidth;
		} else if(pos == 1){
			cMargin = -(expandWidth - cWidth);
		} else{
			cMargin = 0;
		}
	
		if(!pause){
			pause = 1;
			intervalCount = 0;
			intoInterval = setInterval(iconTrans, 15);
		}
		return;
	}

	for(var i = 0; i < n; ++i){
		icon[i].style["margin-left"] = "0";
		icon[i].style.width = "64px";
	}
	
	for(var i = leftIndex; i < rightIndex; ++i){
		icon[i].style["margin-left"] = "0";
		setSize(i, x - iconLeft[i] - 32);
	}

	if(pos == 0){
		container.style["margin-left"] = (expandWidth - container.getBoundingClientRect().width) + "px";
	} else if(pos == 1){
		container.style["margin-left"] = -(expandWidth - container.getBoundingClientRect().width) + "px";
	} else{
		container.style["margin-left"] = "0";
		var idle = (expandWidth - container.getBoundingClientRect().width) / (rightIndex - leftIndex) + "px";
		for(var i = leftIndex; i < rightIndex; ++i)
			icon[i].style["margin-left"] = idle;
	}
}

function mouseEnter(e){
	var x = e.clientX;
	if(x > container.getBoundingClientRect().right || x < container.getBoundingClientRect().left)
		return;
	calcInitSize(x);
}

function mouseMove(e){
	var x = e.clientX;
	if(x > container.getBoundingClientRect().right || x < container.getBoundingClientRect().left)
		return;
	calcInitSize(x);
}

function mouseLeave(e){
	for(var i = 0; i < n; ++i)
		icon[i].setAttribute("class", "animate");
	container.setAttribute("class", "animate");
	for(var i = 0; i < n; ++i)
		icon[i].style.width = "64px";
	container.style["margin-left"] = "0";
	movein = 0;
	setTimeout(function(){
		for(var i = 0; i < n; ++i){
			icon[i].setAttribute("class", "");
			icon[i].style["margin-left"] = "0";
		}
		container.setAttribute("class", "");
	}, 80);
}

window.onload = function(){
	init();
}