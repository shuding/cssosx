CSS-OS-X
========

a CSS/JS build Mac OS X UI

demo: [quietshu.github.io/CSS-OS-X](http://quietshu.github.io/CSS-OS-X)

Author: Shu Ding
Github: github.com/quietshu
Email:  ds303077135@gmail.com

All rights reserved.
